package com.prueba.constant;


public class ViewConstant {
	
	//Constantes para trabajar con las vistas que tenemos
	public static final String CONTACT_FORM="contactform";
	public static final String CONTACTS = "contacts";
	public static final String LOGIN = "login";
	

}
